<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$con=mysqli_connect("127.0.0.1","root","","VehicleParking");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
  