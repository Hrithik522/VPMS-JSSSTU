<?php

require 'connectdb.php';
session_start();
if(!empty($_SESSION["id_no"])){
  header("Location: slotbooking.php");
}
if(isset($_POST["submit"])){
  $id_type = $_POST["id_type"];
  $id_no = $_POST["id_no"];
  $name = $_POST["name"];
  $phone_no = $_POST["phone_no"];
  $alt_phone_no = $_POST["alt_phone_no"];
  $vehicle_type = $_POST["vehicle_type"];
  $vehicle_no = $_POST["vehicle_no"];
  $visit_purpose = $_POST["visit_purpose"];
  $_SESSION["id_no"]=$id_no;

      $query = "INSERT INTO OTHERS VALUES('$id_type','$id_no','$name','$phone_no','$alt_phone_no','$vehicle_type','$vehicle_no','$visit_purpose')";
      mysqli_query($conn, $query);
    //   echo
    //   "<script> alert('Registration Successful'); </script>";
      header("Location: slotbookoth.php");
   
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Others Registration Form</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto|Sriracha&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style1.css">
</head>
<body>
    
<img class="bg" src="bg1.jpeg" alt="Vechile Parking">
    <div class="container">
        <h1>OTHER'S DETAILS FORM</h1>
        <!-- <p>Enter your details and submit this form to confirm your parking</p> -->
        
    
        <form action="" method="post">
            <input type="text" name="id_type" id="id_type" placeholder="Enter your ID TYPE">
            <input type="text" name="id_no" id="id_no" placeholder="Enter your ID NO. ">
            <input type="text" name="name" id="name" placeholder="Enter your Name">
            <input type="phone" name="phone_no" id="phone_no" placeholder="Enter your phone no" maxlength="10">
            <input type="phone" name="alt_phone_no" id="alt_phone_no" placeholder="Enter your alternate phone no" maxlength="10">
            <input type="text" name="vehicle_type" id="vehicle_type" placeholder="Enter your Vehicle TYPE">
            <input type="text" name="vehicle_no" id="vehicle_no" placeholder="Enter your Vehicle NO. ">
            <textarea name="visit_purpose" id="visit_purpose" cols="4" rows="4" placeholder="Enter your purpose of visit"></textarea>
            <button class="btn" name="submit" type="submit">Submit</button> 
        </form>
    </div>
 
    
</body>
</html