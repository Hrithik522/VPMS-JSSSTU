
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release-pro/v4.0.0/css/solid.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <title>Document</title>
    <link rel="stylesheet" href="/styles.css">
</head>
<body>
    
	<div class="section">
		<div class="container">
			<div class="row full-height justify-content-center">
				<div class="col-12 text-center align-self-center py-5">
					<div class="section pb-5 pt-5 pt-sm-2 text-center">
						
						<div class="card-3d-wrap mx-auto">
							<div class="card-3d-wrapper">
								<div class="card-front">
									<div class="center-wrap">
										<div class="section text-center">
											<h4 class="mb-4 pb-3">Booking confirmed! &nbsp;<img src="img_confirm.png" height="25"></h4>
                      <?php
                      include 'connectdb.php';
					  session_start();
					  $usid=$_SESSION["user_id"];
					
                      $wc = $_POST['wing'];
                      $veh = $_POST['vehicle'];
					  if($wc=="AdminBlock"){
						  $ans="AD";
					  }
					  else if($wc=="GoldenJublee"){
						  $ans="GB";
					  }
					  else if($wc=="PS"){
						  $ans="PS";
					  }
					  else {
						  $ans="MCV";
					  }
                      
                      
					  $sql2 = "SELECT * from users where user_id='$usid' ";
					  $res2 = mysqli_query($conn, $sql2);
					  $row2 = mysqli_fetch_assoc($res2);
					  $userdesig=$row2['user_desig'];
	
                        
                       $sql1 = "SELECT * from PARKING_LOT where wing_code='$ans' AND vehicle_type='$veh' AND reserved_for='$userdesig' and slot_id not in (select slot_id from HOURS_USER where end_time is null) LIMIT 1";
                          $res1 = mysqli_query($conn, $sql1);
                          $row1 = mysqli_fetch_assoc($res1);
						  if(mysqli_num_rows($res1) < 1){
							header("Location: notconfirm.php");
						  }
						  $sid = $row1['slot_id'];
                          echo "BOOKING DETAILS :"."<br>"."SLOT_ID :  ".$row1['slot_id'];
						  echo "<br>"."PLACE : "."$wc"; 
						  date_default_timezone_set('Asia/Kolkata');
						  $date = date('Y/m/d H:i:s');
                          echo "<br>"."DATE : ".date('d-m-y');
                          echo "<br>"."START TIME : ".date('h:i:s');
						  
						 if(mysqli_num_rows($res1) > 0){
							 $sql3="INSERT into HOURS_USER values ('$usid','$sid','$date',null)";

							 mysqli_query($conn, $sql3);
						  
						 }
						 
						 if(isset($_GET["submit"])){
							 $date2=date('Y/m/d H:i:s');
                            $sql4 = "UPDATE HOURS_USER set end_time='$date2' where user_id='$usid' ";
							mysqli_query($conn, $sql4);
							header("Location: login.php");
						 }
                      
                      
                      ?>

										<br>
							
										<form action="" method="get">
											
											<button class="btn mt-4" type="submit" name="submit">Cancel Booking</button>
						</form>
				      					</div>
			      					</div>
			      				</div>
								
			      			</div>
			      		</div>
			      	</div>
		      	</div>
	      	</div>
	    </div>
	</div>
</body>
</html>
	