<?php
include 'connectdb.php';
// if(!empty($_SESSION["user_id"])){
//   header("Location: slotbooking.php");
// }
session_start();
// $ms1 = "ham bhagwan";
// $_SESSION['firstmsg']=$ms1;
if(isset($_POST["submit"])){
  $usernameemail = $_POST["usernameemail"];
  $password = $_POST["password"];
  // if($usernameemail=='admin123'&&$password=='Admin@1234') header("Location: /vpms/admin/dashboard.php");
  // else{
  $result = mysqli_query($conn, "SELECT * FROM users WHERE user_id = '$usernameemail' OR email = '$usernameemail'");
  $row = mysqli_fetch_assoc($result);
  if(mysqli_num_rows($result) > 0){
    $verify=password_verify($password,$row['password']);
    if($verify){
      if($useremail=='admin123')header("Location: /vpms/admin/dashboard.php");
      $_SESSION["login"] = true;
      $_SESSION["user_id"] = $row["user_id"];
      $ms1=$row["user_id"];
      $_SESSION['usid']=$ms1;
      header("Location: slotbooking.php");
    }
    else{
      echo
      "<script> alert('Wrong Password'); </script>";
    }
  }
  else{
    echo
    "<script> alert('User Not Registered'); </script>";
  }

}?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login page in HTML</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <img class="bg" src="bg1.jpeg" alt="Vechile Parking">
    <h1>Login Here! </h1>
    <form action="" method="post">
        <!-- Headings for the form -->
        <div class="headingsContainer">
            <h3>Sign in</h3>
            <p>Sign in with your username and password</p>
        </div>

        <!-- Main container for all inputs -->
        <div class="mainContainer">
            <!-- Username -->
            <label for="usernameemail">Enter User ID or EMAIL</label>
            <input type="text" placeholder="Enter Username" name="usernameemail" id="usernameemail" required>

            <br><br>

            <!-- Password -->
            <label for="password">Enter password</label>
            <input type="password" placeholder="Enter Password" name="password" id="password" required>

           
            <button type="submit" name="submit">Login</button>

            
            <p class="register">Not a member?  <a href="index1.php">Register here!</a></p>

        </div>

    </form>
</body>
</html>