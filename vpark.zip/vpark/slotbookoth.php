<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release-pro/v4.0.0/css/solid.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <title>Document</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    
	<div class="section">
		<div class="container">
			<div class="row full-height justify-content-center">
				<div class="col-12 text-center align-self-center py-5">
					<div class="section pb-5 pt-5 pt-sm-2 text-center">
						
						<div class="card-3d-wrap mx-auto">
							<div class="card-3d-wrapper">
								<div class="card-front">
									<div class="center-wrap">
										<div class="section text-center">
											<h4 class="mb-4 pb-3">Slot booking</h4>
											<form action="confirm_oth.php" method="POST">
											<div class="form-group">
												
                                                <select name="wing" class="form-style" required>
                                                    <option value="" disabled selected hidden>Select Place</option>
                                                    <option class="form-style" value="GoldenJublee" >GoldenJublee</option>
                                                    <option value="AdminBlock">AdminBlock</option>
                                                    <option value="PS">PolymerScience</option>
                                                    <option value="MCV">MCV</option>
                                                  </select>
												<i class="input-icon uil uil-at"></i>
											</div>	
											<div class="form-group mt-2">
                                                <select name="vehicle" class="form-style" required>
                                                    <option value="" disabled selected hidden>Select Vehicle Type</option>
                                                    <option value="Car" >Car</option>
                                                    <option value="Bike">Bike</option>
                                                    <option value="Bus">Bus</option>
    
                                                  </select>
												<i class="input-icon uil uil-lock-alt"></i>
											</div>
											<input type="submit" class="btn mt-4" name="submit" value="submit">
										</form>
										
									
											
				      					</div>
			      					</div>
			      				</div>
								
			      			</div>
			      		</div>
			      	</div>
		      	</div>
	      	</div>
	    </div>
	</div>
</body>
</html>