<!DOCTYPE html>
<html lang="en">

<head>
    <title>SELECTION</title>

    <!-- <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet"> -->
    <!--Stylesheet-->
    <style media="screen">
        *,
        *:before,
        *:after {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #080710;
        }

        .background {
            width: 430px;
            height: 420px;
            position: absolute;
            transform: translate(-50%, -50%);
            left: 50%;
            top: 50%;
        }

        .background .shape {
            height: 150px;
            width: 150px;
            position: absolute;
            border-radius: 50%;
        }

        .shape:first-child {
            background: linear-gradient(#1845ad,
                    #23a2f6);
            left: -60px;
            top: -80px;
        }

        .shape:last-child {
            background: linear-gradient(to right,
                    #ff512f,
                    #f09819);
            right: -30px;
            bottom: -80px;
        }

        form {
            height: 420px;
            width: 400px;
            background-color: rgba(255, 255, 255, 0.13);
            position: absolute;
            transform: translate(-50%, -50%);
            top: 50%;
            left: 50%;
            border-radius: 10px;
            backdrop-filter: blur(10px);
            border: 2px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 0 40px rgba(8, 7, 16, 0.6);
            padding: 50px 35px;
        }

        form * {
            font-family: 'Poppins', serif;
            color: #ffffff;
            letter-spacing: 0.5px;
            outline: none;
            border: none;
        }

        form h3 {
            font-size: 33px;
            font-weight: 500;
            line-height: 42px;
            text-align: center;
        }

        label {
            display: block;
            margin-top: 30px;
            font-size: 16px;
            font-weight: 500;
        }

        input {
            display: block;
            height: 50px;
            width: 100%;
            background-color: rgba(255, 255, 255, 0.07);
            border-radius: 3px;
            padding: 0 10px;
            margin-top: 8px;
            font-size: 14px;
            font-weight: 300;
        }

        ::placeholder {
            color: #e5e5e5;
        }

        button {
            margin-top: 50px;
            width: 100%;
            background-color: #ffffff;
            color: #080710;
            padding: 15px 0;
            font-size: 18px;
            font-weight: 600;
            border-radius: 5px;
            cursor: pointer;
        }

        .social {
            margin-top: 30px;
            display: flex;
        }

        .social div {
            background: red;
            width: 150px;
            border-radius: 3px;
            padding: 5px 10px 10px 5px;
            background-color: rgba(255, 255, 255, 0.27);
            color: #eaf0fb;
            text-align: center;
        }

        .social div:hover {
            background-color: rgba(255, 255, 255, 0.47);
        }

        .social .fb {
            margin-left: 25px;
        }

        .social i {
            margin-right: 4px;
        }

        .USER,
        .OTHERS {
            font-size: 25px;
            margin: auto;
            padding: auto;
            text-align: center;

        }

        input[type='radio'] {
            transform: scale(0.6);



        }

        .bg {
            width: 100%;
            position: absolute;
            z-index: -1;
            opacity: 0.6;
        }
        h1{
            font-size: 32px;
  text-shadow: -1px -1px rgb(204, 201, 0), 1px 1px #060, -3px 0 4px #000;
  font-family:Arial, Helvetica, sans-serif;
  color: ORANGE;
  padding:16px;
  font-weight:lighter;
  -moz-box-shadow: 2px 2px 6px #888;  
  -webkit-box-shadow: 2px 2px 6px #888;  
  box-shadow:2px 2px 6px #888;  
  text-align:center;
  display:block;
  margin:16px;
  /* background-image:url(images/background-h1-wood.jpg);  */
        }
    </style>
</head>

<body>
    <h1>VEHICLE PARKING MANAGEMENT SYSTEM @JSSSTU </h1>
    <img class="bg" src="bg1.jpeg" alt="Vechile Parking">
    <div class="background">
        <div class="shape"></div>
        <div class="shape"></div>
    </div>
    <form>
        <fieldset>
            <legend>
                <!-- <h1>!!WELCOME!!</h1> -->
                <h3> &nbsp;&nbsp;&nbsp;Choose an user type: </h3><br><br>
            </legend>

            <!-- <input type="radio" id="option" name="option" value="USER"> -->
            <a href="login.php">
                <label class="USER">NORMAL USER</label><br><br>
            </a>

            <!-- <input type="radio" id="option" name="option" value="OTHERS"> -->
           <a href="index2.php">
           <label class="OTHERS">OTHERS</label><br><br>
           </a>
           <a href="login.php">
                <label class="USER">ADMIN</label><br>
            </a>

        </fieldset>


        <!-- <a href="index2.html">
            <button>Submit</button>
        </a> -->

    </form>
</body>

</html>