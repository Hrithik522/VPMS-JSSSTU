<?php
include 'connectdb.php';
if(!empty($_SESSION["user_id"])){
  header("Location: slotbooking.php");
}
if(isset($_POST["submit"])){
  $user_desig = $_POST["user_desig"];
  $user_id = $_POST["user_id"];
  $username = $_POST["username"];
  $email = $_POST["email"];
  $password = $_POST["password"];
  $hash=password_hash($password,PASSWORD_DEFAULT);
  $phone_no = $_POST["phone_no"];
  $alt_phone_no = $_POST["alt_phone_no"];
  $confirmpassword = $_POST["confirmpassword"];
  $duplicate = mysqli_query($conn, "SELECT * FROM users WHERE user_id = '$user_id' OR email = '$email'");
  if(mysqli_num_rows($duplicate) > 0){
    echo
    "<script> alert('Userid or Email Has Already Taken'); </script>";
  }
  else{
    if($password == $confirmpassword){
      $query = "INSERT INTO users VALUES('$user_desig','$user_id','$username','$email','$hash','$phone_no','$alt_phone_no')";
      mysqli_query($conn, $query);
      echo
      "<script> alert('Registration Successful'); </script>";
    }
    else{
      echo
      "<script> alert('Password Does Not Match'); </script>";
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Travel Form</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto|Sriracha&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style1.css">
</head>
<body>
<img class="bg" src="bg1.jpeg" alt="Vechile Parking">
    <div class="container">
        <h1>USERS SIGN UP FORM</h1>
        <p>Enter your details </p>
        
    
        <form class="" action="" method="post" autocomplete="off">
            <label for="user_desig"></label>
            <!-- <input type="text" name="user_desig" id = "user_desig" placeholder="User Designation" required value="">  -->
            <select name="user_desig" required>
                                                    <option value="" disabled selected hidden>User Designation</option>
                                                    <option value="PRINCIPAL">PRINCIPAL</option>
                                                    <option value="VICE PRINCIPAL">VICE PRINCIPAL</option>
                                                    <option value="REGISTRAR">REGISTRAR</option>
                                                    <option value="FACULTY">FACULTY</option>
                                                    <option  value="STUDENT" >STUDENT</option>
                                                    <option value="STAFF">STAFF</option>
                                                  </select>
            <label for="user_id"></label>
            <input type="text" name="user_id" id = "user_id" placeholder="User ID" required value=""> 
            <label for="username"></label>
            <input type="text" name="username" id = "username" placeholder="Username" required value=""> 
            <label for="email"></label>
            <input type="email" name="email" id = "email" placeholder="Email" required value=""> 
            <label for="password"></label>
            <input type="password" name="password" id = "password" placeholder="Password" required value=""> 
            <label for="confirmpassword"></label>
            <input type="password" name="confirmpassword" id = "confirmpassword" placeholder="Confirm Password" required value=""> 
            <label for="phone_no"></label>
            <input type="text" name="phone_no" id = "phone_no" placeholder="Phone no" maxlength="10" required value="" > 
            <label for="alt_phone_no"></label>
            <input type="text" name="alt_phone_no" id = "alt_phone_no" placeholder="Alternate Phone no" maxlength="10" > 
            
            <button type="submit" class="btn" name="submit">Register</button> <br>
            <button class="btn" href="login.php">Login If Registered</button>
        </form>
          <br>
    </div>
 
    
</body>
</html>